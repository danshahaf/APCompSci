package P4D_ClassRosterProjectTemplate;

public class ClassRoster
   {
   

   public ClassRoster( String initialCourseName )
      {
      //studentList.add( new Student( "Super", "Man", 12, 1, 1, 1, 1, 1 ) );
      //studentList.add( new Student( "Silver", "Surfer", 11, 2, 2, 2, 2, 2 ) );
      //studentList.add( new Student( "Captain", "America", 12, 3, 3, 3, 3, 3 ) );
      //studentList.add( new Student( "Bat", "Man", 11, 4, 4, 4, 4, 4 ) );
      //studentList.add( new Student( "Black", "Panther", 11, 5, 5, 5, 5, 5 ) );
    
          
      } // end zero-arg constructor
      
   public String studentWithMaxGPA()
      {
      
          
      
      return null;
      } // end method studentWithMaxGPA 
       
   public int dropStudent( int minGradeLevel )
      {
      
      return 0;
      } // end method dropStudent
      
   public void addStudent( Student newStudent )
      {
          
      } // end method addStudent
       
      
   public String toString()
      {
      String output = new String();
//       output += "Class: " + courseName + "\n";
//       
//       for( int index = 0; index < studentList.size(); index++ )
//          {
//          output += studentList.get( index ) + "\n";  
//          } // end for
      return output;
      } // end method toString
   } // end ClassRoster