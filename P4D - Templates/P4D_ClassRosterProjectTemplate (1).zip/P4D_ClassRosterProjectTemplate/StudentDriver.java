package P4D_ClassRosterProjectTemplate;

public class StudentDriver
   {
   public static void main( String args[] )
      {
      Student frosh = new Student( "The", "Flash", 9, 1, 1, 1, 1, 1 );    
      Student senior = new Student( "Incredible", "Hulk", 12, 2, 2, 2, 2, 2 );
      
      System.out.println( frosh + "\n" );
      System.out.println( senior + "\n");
          
      } // end method main
       
       
   } // end class StudentDriver